from django.contrib import messages
from django.contrib.auth import get_user_model, login, logout
from django.contrib.auth.views import LoginView
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import RedirectView

from .forms import UserRegistrationForm, UserAddressForm

User = get_user_model()


class UserRegistrationView(View):
    template_name = 'accounts/user_registration.html'

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('transactions:transaction_report')
        return super().dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        registration_form = UserRegistrationForm()
        address_form = UserAddressForm()
        return render(request, self.template_name, {
            'registration_form': registration_form,
            'address_form': address_form
        })

    def post(self, request, *args, **kwargs):
        registration_form = UserRegistrationForm(request.POST)
        address_form = UserAddressForm(request.POST)

        if registration_form.is_valid() and address_form.is_valid():
            user = registration_form.save()
            address = address_form.save(commit=False)
            address.user = user
            address.save()

            login(request, user)
            messages.success(request, f'Thank You For Creating A Bank Account. Your Account Number is {user}.')
            return redirect('transactions:deposit_money')

        return render(request, self.template_name, {
            'registration_form': registration_form,
            'address_form': address_form
        })


class UserLoginView(LoginView):
    template_name = 'accounts/user_login.html'
    redirect_authenticated_user = False


class LogoutView(RedirectView):
    pattern_name = 'home'

    def get_redirect_url(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            logout(self.request)
        return super().get_redirect_url(*args, **kwargs)
