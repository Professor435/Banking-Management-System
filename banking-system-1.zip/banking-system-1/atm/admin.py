from django.contrib import admin
from .models import ATMApplication

@admin.register(ATMApplication)
class ATMApplicationAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'account_no', 'card_type', 'email', 'phone', 'applied_at']
    search_fields = ['full_name', 'account_no', 'email']
    list_filter = ['card_type', 'applied_at']
