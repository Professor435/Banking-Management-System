from django import forms
from .models import ATMApplication  # Replace with your model name

class ATMApplicationForm(forms.ModelForm):
    class Meta:
        model = ATMApplication
        fields = ['full_name', 'account_no', 'email', 'phone', 'card_type', 'address']
        widgets = {
            'full_name': forms.TextInput(attrs={'class': 'w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400'}),
            'account_no': forms.TextInput(attrs={'class': 'w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400'}),
            'email': forms.EmailInput(attrs={'class': 'w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400'}),
            'phone': forms.TextInput(attrs={'class': 'w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400'}),
            'card_type': forms.Select(attrs={'class': 'w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400'}),
            'address': forms.Textarea(attrs={'rows': 3, 'class': 'w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400'}),
        }
