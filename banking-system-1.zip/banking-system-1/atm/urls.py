from django.urls import path
from . import views

app_name = 'atm'  # ✅ Required for using 'namespace="atm"' in include()

urlpatterns = [
    path('apply/', views.apply_for_atm, name='apply_atm'),
]
