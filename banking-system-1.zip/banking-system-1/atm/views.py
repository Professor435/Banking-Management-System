from django.shortcuts import render
from django.core.mail import send_mail, EmailMessage
from django.template.loader import render_to_string
from django.conf import settings
from .forms import ATMApplicationForm
from xhtml2pdf import pisa
from io import BytesIO
from .models import ATMApplication




def generate_pdf(application):
    html = render_to_string('atm/pdf_template.html', {'application': application})
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8")), result)
    if not pdf.err:
        return result.getvalue()
    return None

def apply_for_atm(request):
    if request.method == 'POST':
        form = ATMApplicationForm(request.POST)
        if form.is_valid():
            application = form.save()

            # 1. Confirmation Email to User
            subject = 'ATM Application Confirmation'
            message = (
                f"Dear {application.full_name},\n\n"
                f"Your ATM card application has been received successfully.\n"
                f"Our team will contact you soon.\n\n"
                f"Regards,\nBanking Team"
            )
            send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [application.email])

            # 2. PDF for Admin
            pdf_content = generate_pdf(application)
            email = EmailMessage(
                subject=f"New ATM Application from {application.full_name}",
                body="Please find the attached ATM application details.",
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[settings.DEFAULT_FROM_EMAIL],
            )
            if pdf_content:
                email.attach("atm_application.pdf", pdf_content, 'application/pdf')
            email.send()

            return render(request, 'atm/success.html')
    else:
        form = ATMApplicationForm()
    
    return render(request, 'atm/apply_atm.html', {'form': form})
