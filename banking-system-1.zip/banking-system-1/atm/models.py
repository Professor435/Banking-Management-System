from django.db import models
from django.utils import timezone

CARD_TYPE_CHOICES = [
    ('debit', 'Debit Card'),
    ('credit', 'Credit Card'),
]

class ATMApplication(models.Model):
    account_no = models.CharField(max_length=20)
    full_name = models.CharField(max_length=100)
    email = models.EmailField()  # <-- Make sure this line exists
    card_type = models.CharField(max_length=10, choices=CARD_TYPE_CHOICES)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    applied_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.full_name} - {self.card_type.title()}"
